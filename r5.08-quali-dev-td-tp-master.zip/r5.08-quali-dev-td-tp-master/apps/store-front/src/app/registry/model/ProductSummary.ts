export interface ProductSummary {
    id: string;
    skuId: string;
    name: string;
    status: string;
    catalogs: number;
}