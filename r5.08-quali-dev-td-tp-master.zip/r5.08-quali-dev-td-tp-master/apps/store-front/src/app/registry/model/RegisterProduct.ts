export interface RegisterProductParams {
    name: string;
    description: string;
    skuId: string;
}