export interface ProductStreamElement {
    type: string;
    productId: string;
    occuredAt: Date;
}
