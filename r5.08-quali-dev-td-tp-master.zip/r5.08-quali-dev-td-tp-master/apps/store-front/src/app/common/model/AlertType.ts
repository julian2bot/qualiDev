export enum AlertType {
    SUCCESS,
    ERROR,
    INFO
}