import { AlertType } from "./AlertType";

export interface Alert {
    message: string;
    type: AlertType;
}
