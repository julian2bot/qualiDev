package org.ormi.priv.tfa.orderflow.store.infra.api.dto;

public record RetireProductDto(
        String id) {
}
