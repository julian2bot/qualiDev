[Back to root](../README.md#documentation)

# Doc root

Here lies the technical and functional documentation.

## Table of contents

- [Business](./business/index.md)
- Practical work material : /doc/material -> Run the doc