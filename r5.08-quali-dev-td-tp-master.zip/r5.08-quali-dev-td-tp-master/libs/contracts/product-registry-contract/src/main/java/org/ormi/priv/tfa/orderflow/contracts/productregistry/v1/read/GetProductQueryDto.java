package org.ormi.priv.tfa.orderflow.contracts.productregistry.v1.read;

public record GetProductQueryDto() {
    
}
