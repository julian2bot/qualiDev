package org.ormi.priv.tfa.orderflow.contracts.productregistry.v1.write;

public record UpdateProductNameParamsDto(String name) {
}
