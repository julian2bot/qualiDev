package org.ormi.priv.tfa.orderflow.cqrs.infra.persistence;

import org.ormi.priv.tfa.orderflow.cqrs.EventEnvelope;
import org.ormi.priv.tfa.orderflow.cqrs.infra.jpa.EventLogEntity;

/**
 * TODO: Complete Javadoc
 */

public interface EventLogRepository {
    EventLogEntity append(EventEnvelope<?> eventLog);
}
