package org.ormi.priv.tfa.orderflow.kernel.product;

/**
 * TODO: Complete Javadoc
 */

public enum ProductLifecycle {
    ACTIVE,
    RETIRED
}
